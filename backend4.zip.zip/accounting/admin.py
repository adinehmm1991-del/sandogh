from .models import Transaction, ProfitPeriod, ProfitDistribution, WithdrawalRequest # ایمپورت جدید
from django.contrib import admin
from django.utils.html import format_html
from jalali_date.admin import ModelAdminJalaliMixin
from .models import Transaction, ProfitPeriod, ProfitDistribution

# تنظیمات نمایش تراکنش‌ها
@admin.register(Transaction)
class TransactionAdmin(ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('user', 'amount', 'get_type_display', 'date', 'is_verified')
    list_filter = ('transaction_type', 'is_verified', 'date')
    search_fields = ('user__full_name', 'user__phone_number', 'amount')
    
    def get_type_display(self, obj):
        return obj.get_transaction_type_display()
    get_type_display.short_description = 'نوع تراکنش'

# تنظیمات نمایش دوره‌های سود (همراه با دکمه محاسبه)
@admin.register(ProfitPeriod)
class ProfitPeriodAdmin(ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('name', 'start_date', 'end_date', 'total_profit_amount', 'is_calculated', 'calculate_btn')
    
    # ساخت دکمه سبز رنگ برای محاسبه
    def calculate_btn(self, obj):
        return format_html(
            '<a class="button" href="/api/accounting/calculate-profit/{}/" target="_blank" style="background-color: #28a745; color: white; padding: 5px 10px; border-radius: 5px; text-decoration: none;">محاسبه و تقسیم سود</a>',
            obj.id
        )
    calculate_btn.short_description = "عملیات"
    calculate_btn.allow_tags = True

# تنظیمات نمایش لیست توزیع سود
@admin.register(ProfitDistribution)
class ProfitDistributionAdmin(admin.ModelAdmin):
    list_display = ('user', 'period', 'calculated_score', 'profit_amount')
    list_filter = ('period',)
    search_fields = ('user__full_name', 'user__phone_number')

@admin.register(WithdrawalRequest)
class WithdrawalRequestAdmin(ModelAdminJalaliMixin, admin.ModelAdmin):
    list_display = ('user', 'amount', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('user__full_name', 'user__phone_number')
    readonly_fields = ('created_at',)