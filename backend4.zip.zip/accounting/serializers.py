from rest_framework import serializers
from .models import Transaction

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        # لیست فیلدها
        fields = [
            'id', 'amount', 'transaction_type', 
            'date', 'effective_date', # این را اضافه کردیم تا در پاسخ دیده شود
            'description', 'receipt_image', 'is_verified'
        ]
        
        # فیلدهایی که کاربر نباید پر کند (خودکار هستند)
        read_only_fields = ['id', 'is_verified', 'effective_date'] 

    def validate(self, data):
        # بررسی اینکه اگر تراکنش واریزی است، عکس فیش داشته باشد
        # (برداشت وجه عکس نمیخواد)
        if data.get('transaction_type') != 'WITHDRAWAL':
            if not data.get('receipt_image'):
                raise serializers.ValidationError({"receipt_image": "لطفاً تصویر فیش واریزی را آپلود کنید."})
        return data
from .models import Transaction, WithdrawalRequest # ایمپورت جدید

class WithdrawalRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = WithdrawalRequest
        fields = ['id', 'amount', 'description', 'status', 'created_at', 'admin_note']
        read_only_fields = ['id', 'status', 'created_at', 'admin_note']
    
    # اعتبارسنجی موجودی (اختیاری ولی حرفه‌ای)
    def validate_amount(self, value):
        # اینجا می‌توانید چک کنید کاربر اندازه کافی موجودی داشته باشد
        # فعلا برای سادگی می‌گذریم، اما در آینده قابل افزودن است
        if value < 10000:
            raise serializers.ValidationError("حداقل مبلغ برداشت ۱۰,۰۰۰ تومان است.")
        return value