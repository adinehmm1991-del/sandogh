from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.http import HttpResponse
from jalali_date.admin import ModelAdminJalaliMixin
from .models import User
from .forms import UserCreationForm
import openpyxl
from datetime import datetime
# نکته: ایمپورت Transaction را داخل تابع می‌گذاریم تا تداخل نکند

@admin.action(description='📥 دانلود خروجی اکسل کامل (اعضا + تراکنش‌ها)')
def export_users_to_excel(modeladmin, request, queryset):
    # 1. آماده‌سازی فایل
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    )
    response['Content-Disposition'] = f'attachment; filename=Full_Export_{datetime.now().strftime("%Y-%m-%d")}.xlsx'
    
    workbook = openpyxl.Workbook()
    
    # --- شیت اول: لیست اعضا ---
    ws_users = workbook.active
    ws_users.title = 'لیست اعضا'
    ws_users.sheet_view.rightToLeft = True

    headers_users = [
        'کد عضویت', 'نام و نام خانوادگی', 'شماره موبایل', 'کد ملی', 
        'نقش', 'جنسیت', 'شماره کارت', 'شماره شبا', 
        'تعهد ماهیانه (ریال)', 'وضعیت', 'تاریخ عضویت'
    ]
    ws_users.append(headers_users)

    for user in queryset:
        from accounting.models import Transaction # ایمپورت داخلی
        has_paid = Transaction.objects.filter(user=user, transaction_type='FEE', is_verified=True).exists()
        status_text = "فعال" if has_paid else "غیرفعال"
        date_joined = user.date_joined.strftime('%Y/%m/%d') if user.date_joined else '-'

        row = [
            user.membership_code,
            user.full_name,
            user.phone_number,
            user.national_code,
            user.get_role_display(),
            user.get_gender_display(),
            user.card_number,
            user.shaba_number,
            user.monthly_commitment,
            status_text,
            date_joined
        ]
        ws_users.append(row)

    # --- شیت دوم: ریز تراکنش‌ها ---
    ws_trans = workbook.create_sheet(title='ریز تراکنش‌ها')
    ws_trans.sheet_view.rightToLeft = True

    headers_trans = [
        'نام عضو', 'کد عضویت', 'نوع تراکنش', 'مبلغ (تومان)', 
        'تاریخ ثبت', 'تاریخ مؤثر', 'وضعیت تایید', 'توضیحات', 'کد رهگیری'
    ]
    ws_trans.append(headers_trans)

    # پیدا کردن تمام تراکنش‌های مربوط به کاربران انتخاب شده
    from accounting.models import Transaction
    transactions = Transaction.objects.filter(user__in=queryset).order_by('-date')

    for trans in transactions:
        # تبدیل تاریخ به متن ساده
        trans_date = trans.date.strftime('%Y/%m/%d %H:%M') if trans.date else '-'
        eff_date = trans.effective_date.strftime('%Y/%m/%d') if trans.effective_date else '-'
        is_verified_text = "✅ تایید شده" if trans.is_verified else "⏳ در انتظار"

        row = [
            trans.user.full_name,
            trans.user.membership_code,
            trans.get_transaction_type_display(), # متن فارسی نوع تراکنش
            trans.amount,
            trans_date,
            eff_date,
            is_verified_text,
            trans.description,
            trans.bank_tracking_code or '-'
        ]
        ws_trans.append(row)

    # ذخیره نهایی
    workbook.save(response)
    return response


@admin.register(User)
class UserAdmin(ModelAdminJalaliMixin, BaseUserAdmin):
    add_form = UserCreationForm
    actions = [export_users_to_excel] # اضافه کردن اکشن جدید

    list_display = ('phone_number', 'full_name', 'membership_code', 'role', 'is_active_status')
    list_filter = ('role', 'is_active', 'gender')
    search_fields = ('phone_number', 'full_name', 'membership_code', 'national_code')
    ordering = ('phone_number',)
    readonly_fields = ('membership_code', 'last_login', 'date_joined')

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('phone_number', 'full_name', 'password', 'confirm_password'),
        }),
    )

    fieldsets = (
        (None, {'fields': ('phone_number', 'password')}),
        ('اطلاعات شخصی', {'fields': ('full_name', 'national_code', 'gender', 'birth_date', 'social_id')}),
        ('اطلاعات حساب', {'fields': ('role', 'membership_code', 'referral_code')}),
        ('اطلاعات مالی و بانکی', {'fields': ('card_number', 'shaba_number', 'monthly_commitment')}),
        ('دسترسی‌ها', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('تاریخچه‌ها', {'fields': ('last_login', 'date_joined')}),
    )
    
    def is_active_status(self, obj):
        from accounting.models import Transaction
        has_paid = Transaction.objects.filter(user=obj, transaction_type='FEE', is_verified=True).exists()
        return "✅ فعال" if has_paid else "❌ غیرفعال"
    is_active_status.short_description = "وضعیت"

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if not obj:
            form.base_fields['confirm_password'] = form.base_fields.get('password')
        return form