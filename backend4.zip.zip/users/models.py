from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.utils import timezone
import random
import string

# 1. مدیر شخصی‌سازی شده
class CustomUserManager(BaseUserManager):
    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError('شماره موبایل باید وارد شود')
        user = self.model(phone_number=phone_number, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, phone_number, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        return self.create_user(phone_number, password, **extra_fields)

# 2. جدول کاربران
class User(AbstractUser):
    username = None

    class Roles(models.TextChoices):
        ADMIN = 'ADMIN', 'مدیر سیستم'
        OBSERVER = 'OBSERVER', 'ناظر'
        MEMBER = 'MEMBER', 'عضو عادی'
        BENEFACTOR = 'BENEFACTOR', 'خیر'
        FUND_ACCOUNT = 'FUND_ACCOUNT', 'حساب صندوق'

    class Gender(models.TextChoices):
        MALE = 'MALE', 'آقا'
        FEMALE = 'FEMALE', 'خانم'

    phone_number = models.CharField(max_length=11, unique=True, verbose_name="شماره موبایل")
    national_code = models.CharField(max_length=10, unique=True, null=True, blank=True, verbose_name="کد ملی")
    membership_code = models.CharField(max_length=20, unique=True, editable=False, verbose_name="کد عضویت")
    
    full_name = models.CharField(max_length=150, verbose_name="نام و نام خانوادگی")
    gender = models.CharField(max_length=10, choices=Gender.choices, null=True, blank=True, verbose_name="جنسیت")
    birth_date = models.DateField(null=True, blank=True, verbose_name="تاریخ تولد")
    social_id = models.CharField(max_length=100, null=True, blank=True, verbose_name="آیدی پیام‌رسان")
    
    role = models.CharField(max_length=20, choices=Roles.choices, default=Roles.MEMBER, verbose_name="نقش")
    
    card_number = models.CharField(max_length=16, null=True, blank=True, verbose_name="شماره کارت")
    shaba_number = models.CharField(max_length=26, null=True, blank=True, verbose_name="شماره شبا")
    
    referral_code = models.CharField(max_length=20, null=True, blank=True, verbose_name="کد معرف")
    monthly_commitment = models.BigIntegerField(null=True, blank=True, verbose_name="تعهد واریز ماهیانه (ریال)")

    USERNAME_FIELD = 'phone_number'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def save(self, *args, **kwargs):
        if not self.membership_code:
            last_user = User.objects.order_by('id').last()
            if last_user:
                next_id = last_user.id + 1
            else:
                next_id = 1
            self.membership_code = f"313{next_id}"
        super().save(*args, **kwargs)

    class Meta:
        verbose_name = "کاربر"
        verbose_name_plural = "کاربران"

    def __str__(self):
        return self.full_name if self.full_name else self.phone_number

# 3. مدل کد تایید (OTP) - برای فراموشی رمز
class OTP(models.Model):
    phone_number = models.CharField(max_length=11)
    code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)

    @classmethod
    def create_otp(cls, phone):
        # حذف کدهای قبلی این شماره
        cls.objects.filter(phone_number=phone).delete()
        # ساخت کد ۵ رقمی تصادفی
        code = ''.join(random.choices(string.digits, k=5))
        return cls.objects.create(phone_number=phone, code=code)

    def is_valid(self):
        # اعتبار کد فقط ۲ دقیقه باشد
        now = timezone.now()
        diff = now - self.created_at
        return diff.total_seconds() < 120