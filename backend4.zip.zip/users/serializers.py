from rest_framework import serializers
from .models import User

# --- تابع کمکی: تمیز کردن اعداد (تبدیل فارسی/عربی به انگلیسی) ---
def clean_numbers(value):
    if value:
        # حذف فاصله‌ها و کاراکترهای اضافی
        value = value.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
        
        # تبدیل ارقام فارسی و عربی به انگلیسی
        persian_digits = '۰۱۲۳۴۵۶۷۸۹'
        arabic_digits = '٠١٢٣٤٥٦٧٨٩'
        english_digits = '0123456789'
        
        translation_table = str.maketrans(persian_digits + arabic_digits, english_digits * 2)
        return value.translate(translation_table)
    return value


# 1. فرم ثبت‌نام (اصلاح شده)
class UserRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        # فیلد monthly_commitment اضافه شد 👇
        fields = ['phone_number', 'full_name', 'national_code', 'password', 'referral_code', 'monthly_commitment']
        extra_kwargs = {'password': {'write_only': True}}

    # پاکسازی‌ها
    def validate_phone_number(self, value): return clean_numbers(value)
    def validate_password(self, value): return clean_numbers(value)
    def validate_national_code(self, value): return clean_numbers(value)
    def validate_referral_code(self, value): return clean_numbers(value)
    
    # پاکسازی مبلغ تعهد (چون ممکن است کاربر با کاما بفرستد)
    def validate_monthly_commitment(self, value):
        clean_val = clean_numbers(str(value))
        return clean_val if clean_val else None

    def create(self, validated_data):
        user = User.objects.create_user(
            phone_number=validated_data['phone_number'],
            password=validated_data['password'],
            full_name=validated_data.get('full_name', ''),
            national_code=validated_data.get('national_code', ''),
            referral_code=validated_data.get('referral_code', ''),
            # خط جدید: ذخیره تعهد 👇
            monthly_commitment=validated_data.get('monthly_commitment', None),
        )
        return user

# 2. فرم ورود
class UserLoginSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate_phone_number(self, value):
        return clean_numbers(value)

    def validate_password(self, value):
        return clean_numbers(value)


# 3. فرم ویرایش پروفایل
class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'full_name', 'national_code', 'gender', 'birth_date', 
            'card_number', 'shaba_number', 'monthly_commitment'
        ]

    # پاکسازی فیلدهای عددی در پروفایل
    def validate_national_code(self, value):
        return clean_numbers(value)
    
    def validate_card_number(self, value):
        return clean_numbers(value)

    def validate_shaba_number(self, value):
        return clean_numbers(value)

    def validate_monthly_commitment(self, value):
        # چون این فیلد عدد صحیح (Integer) است، باید اول تمیز شود
        clean_val = clean_numbers(str(value))
        if not clean_val: return None
        return clean_val


# 4. فرم درخواست فراموشی رمز (ارسال کد)
class ForgotPasswordRequestSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    
    def validate_phone_number(self, value):
        return clean_numbers(value)


# 5. فرم تایید فراموشی رمز (تغییر رمز نهایی)
class ForgotPasswordVerifySerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    code = serializers.CharField()
    new_password = serializers.CharField(write_only=True)

    def validate_phone_number(self, value):
        return clean_numbers(value)

    def validate_code(self, value):
        return clean_numbers(value)
        
    def validate_new_password(self, value):
        return clean_numbers(value)
# فرم تغییر رمز عبور (داخل پروفایل)
class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    # پاکسازی اعداد فارسی
    def validate_old_password(self, value): return clean_numbers(value)
    def validate_new_password(self, value): return clean_numbers(value)