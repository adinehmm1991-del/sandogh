from django.urls import path
from .views import RegisterView, LoginView, ProfileUpdateView, ForgotPasswordView # <--- همه ویوها ایمپورت شدند
from .views import RegisterView, LoginView, ProfileUpdateView, ForgotPasswordView, ChangePasswordView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('profile/', ProfileUpdateView.as_view(), name='profile-update'),
    path('forgot-password/', ForgotPasswordView.as_view(), name='forgot-password'), # <--- این خط برگشت
    path('change-password/', ChangePasswordView.as_view(), name='change-password')
]