import requests

# --- تنظیمات پنل پیامک ---
ACCESS_HASH = '20b9b796-4f4e-4686-bd89-71a75545f1d8' # کد دسترسی جدید شما
SMS_SENDER = '90000716'
ADMIN_PHONE = '09365466536'

# --- کدهای الگو (اینجا را باید بعد از تایید الگوها پر کنید) ---
# وقتی الگوها تایید شد، کد هر کدام را جلوی اسمش بنویسید
PATTERNS = {
    'otp':'585fb9c1-dad9-4826-9685-514d50d98b96',
    'welcome':'c4105767-d8c6-49d8-adf5-94855c4f5c54',
    'admin_alert':'02f32b11-b357-4efd-89dd-ad29e8a6c69a',
    'verify_deposit':'cc3bfe14-8635-4bc1-b533-b4241fe44763',
    'verify_withdraw': '70a2166f-1162-49e4-9e6b-fd14a97d8789'
}

def send_pattern_sms(receptor, pattern_key, tokens):
    """
    ارسال پیامک پترن (خدماتی)
    receptor: شماره گیرنده
    pattern_key: کلید الگو (مثلا 'otp')
    tokens: دیکشنری مقادیر (مثلا {'token1': 'علی', 'token2': '123'})
    """
    url = "https://smspanel.trez.ir/SendPatternWithUrl.ashx"
    
    pattern_code = PATTERNS.get(pattern_key)
    if not pattern_code:
        print(f"Error: Pattern '{pattern_key}' not found.")
        return False

    params = {
        'AccessHash': ACCESS_HASH,
        'PhoneNumber': SMS_SENDER,
        'PatternId': pattern_code,
        'RecNumber': receptor,
        'Smsclass': '1',
    }
    
    # اضافه کردن توکن‌ها به پارامترها (token1, token2, ...)
    # ورودی tokens باید دیکشنری باشد: {'token1': '...', 'token2': '...'}
    params.update(tokens)
    
    try:
        response = requests.get(url, params=params)
        print(f"SMS Pattern Log -> To: {receptor} | Pattern: {pattern_key} | Result: {response.text}")
        
        if response.text.isdigit() and int(response.text) > 2000:
            return True
        return False
        
    except Exception as e:
        print(f"SMS Error: {e}")
        return False