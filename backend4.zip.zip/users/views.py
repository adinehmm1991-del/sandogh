from .serializers import ChangePasswordSerializer
from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from .serializers import UserRegistrationSerializer, UserLoginSerializer, UserProfileSerializer, ForgotPasswordRequestSerializer
from .models import User
from .utils import send_pattern_sms  # <--- استفاده از تابع جدید پترن
import random
import string

# 1. ثبت‌نام
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            
            # --- ارسال پیامک خوش‌آمد (پترن welcome) ---
            # token1: نام و نام خانوادگی
            # token2: کد عضویت
            send_pattern_sms(user.phone_number, 'welcome', {
                'token1': user.full_name,
                'token2': user.membership_code
            })
            # ------------------------------------------
            
            return Response({
                "message": "ثبت‌نام با موفقیت انجام شد.",
                "user_id": user.id,
                "phone": user.phone_number,
                "code": user.membership_code
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# 2. ورود
class LoginView(generics.GenericAPIView):
    serializer_class = UserLoginSerializer
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            phone = serializer.validated_data['phone_number']
            password = serializer.validated_data['password']
            
            user = authenticate(username=phone, password=password)
            
            if user:
                token, created = Token.objects.get_or_create(user=user)
                return Response({
                    "message": "ورود موفقیت‌آمیز بود.",
                    "token": token.key,
                    "user_id": user.id,
                    "full_name": user.full_name,
                    "role": user.role
                }, status=status.HTTP_200_OK)
            else:
                return Response({"error": "شماره موبایل یا رمز عبور اشتباه است."}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# 3. ویرایش پروفایل
class ProfileUpdateView(generics.RetrieveUpdateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserProfileSerializer
    def get_object(self):
        return self.request.user

# 4. فراموشی رمز
class ForgotPasswordView(generics.GenericAPIView):
    permission_classes = [permissions.AllowAny]
    serializer_class = ForgotPasswordRequestSerializer

    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            phone = serializer.validated_data['phone_number']
            
            # جستجوی هوشمند کاربر
            user = User.objects.filter(phone_number=phone).first()
            if not user:
                if phone.startswith('0'):
                    user = User.objects.filter(phone_number=phone[1:]).first()
                else:
                    user = User.objects.filter(phone_number='0' + phone).first()

            if not user:
                return Response({"error": "کاربری با این شماره یافت نشد."}, status=400)

            # ساخت رمز جدید
            new_password = ''.join(random.choices(string.digits, k=5))
            user.set_password(new_password)
            user.save()

            # --- ارسال رمز جدید (پترن otp) ---
            # token1: رمز جدید
            send_pattern_sms(user.phone_number, 'otp', {
                'token1': new_password
            })
            # -------------------------------

            return Response({"message": "رمز عبور جدید پیامک شد."}, status=200)
        
        return Response(serializer.errors, status=400)
    
# 5. تغییر رمز عبور (توسط کاربر لاگین شده)
class ChangePasswordView(generics.UpdateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ChangePasswordSerializer

    def update(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = request.user
            # چک کردن رمز قدیمی
            if not user.check_password(serializer.validated_data['old_password']):
                return Response({"error": "رمز عبور فعلی اشتباه است."}, status=status.HTTP_400_BAD_REQUEST)
            
            # ذخیره رمز جدید
            user.set_password(serializer.validated_data['new_password'])
            user.save()
            return Response({"message": "رمز عبور با موفقیت تغییر کرد."}, status=status.HTTP_200_OK)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)    
